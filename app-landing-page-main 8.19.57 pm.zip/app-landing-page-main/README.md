# app-landing-page
In this tutorial, I will show you how to create an app landing page step by step using Html, CSS, Bootstrap.
App Landing Page Features Header with navbar and Home Section, About, Features, Testimonial, Pricing, FAQ, Download, Footer, and much more.

Other Features:
Fully Responsive Layout
Html5, Css3, Bootstrap 5
Clean Design
Font Awesome icons
Google Fonts
Created For Web App 

Credits:
Images: Unsplash, freepink, undraw.
Fonts: Google Fonts, font awesome.

